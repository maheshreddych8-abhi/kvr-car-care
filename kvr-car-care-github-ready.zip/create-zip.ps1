Add-Type -AssemblyName System.IO.Compression.FileSystem
$ProgressPreference = 'SilentlyContinue'

$src = 'C:\Users\mahesh.chalimadugu.SMARTIMSHYD\.gemini\antigravity\scratch\kvr-car-care'
$dest = 'C:\Users\mahesh.chalimadugu.SMARTIMSHYD\.gemini\antigravity\scratch\kvr-car-care-github-ready.zip'
if (Test-Path $dest) { Remove-Item $dest -Force }

[System.IO.Compression.ZipFile]::CreateFromDirectory($src, $dest)
$size = (Get-Item $dest).Length
Write-Host "Created fresh zip package: $size bytes at $dest"
